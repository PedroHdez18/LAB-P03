var indexSectionsWithContent =
{
  0: "abdeghimnprstw",
  1: "bep",
  2: "e",
  3: "bep",
  4: "bghimnprstw",
  5: "ad"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Espacios de nombres",
  3: "Archivos",
  4: "Funciones",
  5: "Variables"
};

